# java-File-Backup-Utility

FileChamber
Build Version 1.0 Beta

Backs up your file even in use on a specified number of time to prevent accidental deletion or misplacement with FileChamber.

Copyright (C) 2016, Jentzen Paolo Ancheta Javier

FileChamber comes with ABSOLUTELY NO WARRANTY.
This is a freeware and inspired for educational purposes.
The software includes the solution and source codes. It is fair to give warning upon code manipulation. MODIFY AT YOUR OWN RISK.
Source codes and resources are by-product of intensive research and any familiar methodologies are owned by their respective authors/owners.
This product includes software developed by Java.

SIDE NOTE:
Only run within the root folder e.g (C:\ , D:\, etc.).
Do not place within root folder sub directories which asks special permissions e.g (Program Files, Program Files(x86), etc.).
The solution was made with NetBeans 8.1 IDE. The application can be run with its .EXE shortcut, hence, if lost, navigate to 
the app_FileChamber folder\dist\FileChamber BETA.exe .

Thank you for using FileChamber.
