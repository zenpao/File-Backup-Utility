/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package app_filechamber;

import javax.swing.JFrame;
import java.awt.*;
import java.awt.event.*;
import javax.accessibility.*;

/**
 *
 * @author Zen
 */
public class App_FileChamber extends App_betaFileChamber{

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}
